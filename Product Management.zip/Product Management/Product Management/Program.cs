﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Product_Management
{
    class Program
    {
        static void Main(string[] args)
        {
            ProductInfo[] product = new ProductInfo[10];
            int option;
            int count = 0;
            do
            {
                Console.Clear();
                option = Menu();
                if(option == 1)
                {
                    product[count] = AddProduct(product);
                    count++;
                }
                else if (option == 2)
                {
                    ShowProduct(product, count);
                }
                else if (option == 3)
                {
                    TotalWorth(product, count);
                }
                else
                {
                    Console.WriteLine("Invalid Input.");
                }
            } while (option != 3);
            
        }
        static int Menu()
        {
            int option;
            Console.Clear();
            Console.WriteLine("1.Add Product.");
            Console.WriteLine("2.Show Product.");
            Console.WriteLine("3.Totao Store Worth.");
            Console.Write("Enter Option:");
            option = int.Parse(Console.ReadLine());
            return option;
        }
        static ProductInfo AddProduct(ProductInfo[] products)
        {
            Console.Clear();
            ProductInfo p = new ProductInfo();
            Console.Write("Enter ID :");
            p.ID = int.Parse(Console.ReadLine());
            Console.Write("Enter Name :");
            p.name = Console.ReadLine();
            Console.Write("Enter Price :");
            p.price = float.Parse(Console.ReadLine());
            Console.Write("Enter Category :");
            p.category = Console.ReadLine();
            Console.Write("Enter BrandName :");
            p.brandName = Console.ReadLine();
            Console.Write("Enter Country :");
            p.country = Console.ReadLine();
            return p;
        }
        static void ShowProduct(ProductInfo[] product, int count)
        {
            Console.Clear();
            for(int idx = 0; idx < count; idx++)
            {
                Console.WriteLine("ID: {0}  Name: {1}  Price: {2}  Category: {3}  Brand Name: {4}  Country: {5}", product[idx].ID, product[idx].name, product[idx].price, product[idx].category, product[idx].brandName, product[idx].country);
            }
            Console.ReadKey();
        }
        static void TotalWorth(ProductInfo[] product , int count)
        {
            float sum = 0;
            Console.Clear();
            for (int idx = 0; idx < count; idx++)
            {
                sum = sum + product[idx].price;
            }
            Console.WriteLine("Total Worth: {0}", sum);
            Console.ReadKey();
        }
    }
    
}
