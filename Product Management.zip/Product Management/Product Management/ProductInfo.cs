﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Product_Management
{
    class ProductInfo
    {
        public int ID;
        public string name;
        public float price;
        public string category;
        public string brandName;
        public string country;
    }
}
