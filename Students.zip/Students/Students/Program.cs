﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Students
{
    class Program
    {
        static void Main(string[] args)
        {
            Task03();
        }
        static void Task01()
        {
            studentInfo s01 = new studentInfo();
            s01.name = "Tayyaba";
            s01.roll_no = 134;
            s01.cgpa = 3.25F;
            Console.WriteLine("Name: {0}   Roll_No.: {1}  cgpa:  {2}", s01.name, s01.roll_no, s01.cgpa);
            Console.ReadKey();

            studentInfo s02 = new studentInfo();
            s02.name = "Raveeha";
            s02.roll_no = 149;
            s02.cgpa = 3.99F;
            Console.WriteLine("Name: {0}   Roll_No.: {1}  cgpa:  {2}", s02.name, s02.roll_no, s02.cgpa);
            Console.ReadKey();

            studentInfo s03 = new studentInfo();
            s03.name = "Ayesha";
            s03.roll_no = 151;
            s03.cgpa = 3.66F;
            Console.WriteLine("Name: {0}   Roll_No.: {1}  cgpa:  {2}", s03.name, s03.roll_no, s03.cgpa);
            Console.ReadKey();
        }
        static void Task02()
        {
            studentInfo s04 = new studentInfo();
            Console.Write("Enter Name: ");
            s04.name = Console.ReadLine();
            Console.Write("Enter Roll_no.: ");
            s04.roll_no = int.Parse(Console.ReadLine());
            Console.Write("Enter cgpa: ");
            s04.cgpa = float.Parse(Console.ReadLine());
            Console.WriteLine("Name: {0}   Roll_No.: {1}  cgpa:  {2}", s04.name, s04.roll_no, s04.cgpa);
            Console.ReadKey();
        }
        static void Task03()
        {
            studentInfo[] s = new studentInfo[10];
            int option;
            int count = 0;
            do
            {
                Console.Clear();
                option = Menu();
                if (option == 1)
                {
                    s[count] = AddStudents();
                    count++;
                }
                if (option == 2)
                {
                    ViewStudents(s, count);
                }
                if (option == 3)
                {
                    TopStudents(s, count);
                }
                if (option == 4)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid Input.");
                }
            }while(option != 4);
        }
        static int Menu()
        {
            int option;
            Console.WriteLine("1.Add Student.");
            Console.WriteLine("2.Show Students.");
            Console.WriteLine("3.Top Students.");
            Console.WriteLine("4.Exit.");
            Console.Write("Enter Option: ");
            option = int.Parse(Console.ReadLine());
            return option;
        }
        static studentInfo AddStudents()
        {
            Console.Clear();
            studentInfo s = new studentInfo();
            Console.Write("Enter Name: ");
            s.name = Console.ReadLine();
            Console.Write("Enter Roll_no.: ");
            s.roll_no = int.Parse(Console.ReadLine());
            Console.Write("Enter cgpa: ");
            s.cgpa = float.Parse(Console.ReadLine());
            Console.Write("Is Hostelite? Y or N: ");
            s.isHostelite = char.Parse(Console.ReadLine());
            Console.Write("Enter department: ");
            s.department = Console.ReadLine();
            return s;
        }
        static void ViewStudents(studentInfo[] s, int count)
        {
            Console.Clear();
            for (int idx = 0; idx < count; idx++)
            {
                Console.WriteLine("Name: {0}   Roll_No.: {1}  cgpa:  {2}  Hostelite: {3}  Departement: {4} ", s[idx].name, s[idx].roll_no, s[idx].cgpa, s[idx].isHostelite, s[idx].department);
            }
            Console.ReadKey();
        }
        static void TopStudents(studentInfo[] s, int count)
        {
            Console.Clear();
            if(count == 0)
            {
                Console.WriteLine("No Record Found.");
            }
            else if(count == 1)
            {
                ViewStudents(s, 1);
            }
            else if (count == 2)
            {
                for(int idx = 0; idx < 2; idx++)
                {
                    int index = Largest(s, idx, count);
                    studentInfo swap = s[index];
                    s[index] = s[idx];
                    s[idx] = swap;
                }
                ViewStudents(s, 2);
            }
            else
            {
                for (int idx = 0; idx < 3; idx++)
                {
                    int index = Largest(s, idx, count);
                    studentInfo swap = s[index];
                    s[index] = s[idx];
                    s[idx] = swap;
                }
                ViewStudents(s, 3);
            }
        }
        static int Largest(studentInfo[] s, int start, int end)
        {
            int index = start;
            float large = s[start].cgpa;
            for (int idx = start; idx < end; idx++)
            {
                if(large < s[idx].cgpa)
                {
                    large = s[idx].cgpa;
                    index = idx;
                }
            }
            return index;
        }
    }
}
