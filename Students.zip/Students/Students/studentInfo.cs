﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Students
{
    class studentInfo
    {
        public string name;
        public int roll_no;
        public float cgpa;
        public char isHostelite;
        public string department;
    }
}
